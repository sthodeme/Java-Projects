public class Main {
    public static void main(String[] args) {
        var calcWindow = new CalcWindow();

        System.out.println("#######  end of program ##########");
    }
}
